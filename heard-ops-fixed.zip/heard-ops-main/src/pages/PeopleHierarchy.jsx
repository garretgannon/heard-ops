import { useState } from 'react';
import { Users, GitBranch, MapPin, Shield } from 'lucide-react';
import EmployeeDirectoryTab from '@/components/people/EmployeeDirectoryTab';
import OrgChartTab from '@/components/people/OrgChartTab';
import OwnershipTab from '@/components/people/OwnershipTab';
import RolesManagerTab from '@/components/people/RolesManagerTab';
import JobCodesTab from '@/components/people/JobCodesTab';
import RolePermissionBuilder from '@/components/AdminDashboard/RolePermissionBuilder';
import AssignmentAuthorityEditor from '@/components/people/AssignmentAuthorityEditor';
import { useNavigate } from 'react-router-dom';

const TABS = [
  { id: 'directory',  label: 'Directory',   icon: Users },
  { id: 'org',        label: 'Org Chart',   icon: GitBranch },
  { id: 'ownership',  label: 'Ownership',   icon: MapPin },
  { id: 'roles',      label: 'Roles',       icon: Shield },
  { id: 'permissions',label: 'Permissions', icon: Shield },
  { id: 'job-codes',  label: 'Job Codes',   icon: Shield },
];

const DEFAULT_AUTHORITY = [
  { role: 'Admin', canAssign: 'All roles' },
  { role: 'General Manager', canAssign: 'All roles' },
  { role: 'Manager', canAssign: 'Kitchen Lead, Line Cook, Prep Cook, Dishwasher, Server, Host, Busser, Bartender' },
  { role: 'Kitchen Lead', canAssign: 'Line Cook, Prep Cook, Dishwasher' },
  { role: 'Bartender', canAssign: null },
  { role: 'Server', canAssign: null },
  { role: 'Host', canAssign: null },
  { role: 'Line Cook', canAssign: null },
  { role: 'Prep Cook', canAssign: null },
];

export default function PeopleHierarchy() {
  const [tab, setTab] = useState('directory');
  const navigate = useNavigate();

  return (
    <div className="pb-28 lg:pb-8 min-h-screen">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-background/95 backdrop-blur border-b border-border/30 px-4 pt-4 pb-0">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h1 className="text-xl font-extrabold text-foreground">People</h1>
            <p className="text-xs text-muted-foreground mt-0.5">Team hierarchy, ownership &amp; access</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-0.5 overflow-x-auto pb-0 -mx-4 px-4">
          {TABS.map(t => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex items-center gap-1.5 px-3.5 py-2.5 text-xs font-bold whitespace-nowrap border-b-2 transition-all ${
                  tab === t.id
                    ? 'border-primary text-primary'
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                {t.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="px-4 pt-4">
        {tab === 'directory' && <EmployeeDirectoryTab />}
        {tab === 'org'       && <OrgChartTab />}
        {tab === 'ownership' && <OwnershipTab />}
        {tab === 'roles'     && <RolesManagerTab />}
        {tab === 'permissions' && (
          <div className="space-y-3">
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              <div className="px-4 py-3 border-b border-border/40">
                <p className="text-sm font-bold text-foreground">Permissions & Visibility</p>
                <p className="text-xs text-muted-foreground mt-0.5">Define what each role can see and do in the app</p>
              </div>
              <div className="p-4">
                <RolePermissionBuilder />
              </div>
            </div>
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              <div className="px-4 py-3 border-b border-border/40">
                <p className="text-sm font-bold text-foreground">Assignment Authority</p>
                <p className="text-xs text-muted-foreground mt-0.5">Who can assign tasks to whom</p>
              </div>
              <div className="p-4">
                <AssignmentAuthorityEditor />
              </div>
              <div className="px-4 py-3 border-t border-border/40 bg-background/50">
                <p className="text-[10px] text-muted-foreground">Individual employee overrides can be set in Directory → Edit Employee → Can Assign Tasks To.</p>
              </div>
            </div>
          </div>
        )}
        {tab === 'job-codes' && <JobCodesTab />}
      </div>
    </div>
  );
}

export const hideBase44Index = true;